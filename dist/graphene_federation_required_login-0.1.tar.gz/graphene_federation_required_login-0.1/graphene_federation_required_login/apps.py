from django.apps import AppConfig


class GrapheneFederationRequiredLoginConfig(AppConfig):
    name = 'graphene_federation_required_login'
